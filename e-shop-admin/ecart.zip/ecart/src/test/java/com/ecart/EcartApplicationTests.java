package com.ecart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcartApplicationTests {

	@Test
	void contextLoads() {
	}

}
